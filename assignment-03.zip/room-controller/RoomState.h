#ifndef __ROOM_STATE__
#define __ROOM_STATE__

// Defines in which type of state the room is currently in.
typedef enum {AUTO, DASHBOARD, BLUETOOTH} RoomState;

#endif
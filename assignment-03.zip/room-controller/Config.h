#define BASE_PERIOD 100
#define LED_PIN 8
#define SERVO_PIN 7
#define BT_RX_PIN 2 // to be connected to TX of the BT module
#define BT_TX_PIN 3 // to be connected to RX of the BT module
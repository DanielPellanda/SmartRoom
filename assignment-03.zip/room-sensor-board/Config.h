#define BASE_PERIOD 200
#define LED_PIN 5
#define PIR_PIN 4
#define LIGHT_PIN A0
